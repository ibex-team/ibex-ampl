#include <windows.h>

 int APIENTRY LibMain(HANDLE hdll, DWORD reason, LPVOID reserved)
 { return 1; }
