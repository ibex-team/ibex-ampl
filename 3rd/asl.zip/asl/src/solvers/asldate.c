long ASLdate_ASL = 20210327;
