long ASLdate_ASL = 20201030;
