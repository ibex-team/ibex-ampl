long ASLdate_ASL = 20210410;
