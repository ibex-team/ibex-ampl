char npopt_version[] = "NPOPT (19980403)";
