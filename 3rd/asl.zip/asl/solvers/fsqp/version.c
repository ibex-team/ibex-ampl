char fsqp_version[] = "CFSQP 2.5c (19980403)";
