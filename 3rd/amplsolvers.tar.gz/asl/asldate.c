long ASLdate_ASL = 20201113;
