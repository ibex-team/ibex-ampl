#define PSEDREAD
#include "ve08.c"
